// ── 配置区 ────────────────────────────────────────────────────────────────────
const CHANNEL_IDS = ["611", "621", "622", "623", "630", "631", "635", "680"];
const CHANNEL_NAMES = {
  "611": "Now Sports 4K 1",
  "621": "Premier League 1",
  "622": "Premier League 2",
  "623": "Premier League 3",
  "630": "Now Sports Prime",
  "631": "Now Sports Prime 2",
  "635": "Now Sports 5",
  "680": "Now Sports Plus",
};
const REMIND_MINUTES = 5;
const BASE_URL = "https://nowplayer.now.com";
const FETCH_HEADERS = {
  "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36",
  "Accept-Language": "zh-HK,zh;q=0.9,en;q=0.8",
  "Referer": BASE_URL,
};
// 关键词过滤（留空 = 全部节目；填关键词只提醒匹配的）
const KEYWORDS = [];
// ─────────────────────────────────────────────────────────────────────────────

function parseTime(raw) {
  if (!raw) return null;
  raw = raw.trim();
  const d = new Date(raw);
  if (!isNaN(d.getTime())) return d;
  const isoLike = raw.match(/^(\d{4}-\d{2}-\d{2})[T ](\d{2}:\d{2}(:\d{2})?)$/);
  if (isoLike) return new Date(`${isoLike[1]}T${isoLike[2]}+08:00`);
  const dmy = raw.match(/^(\d{2})\/(\d{2})\/(\d{4})\s+(\d{2}):(\d{2})/);
  if (dmy) return new Date(`${dmy[3]}-${dmy[2]}-${dmy[1]}T${dmy[4]}:${dmy[5]}:00+08:00`);
  const ts = parseInt(raw, 10);
  if (!isNaN(ts)) return new Date(ts > 1e12 ? ts : ts * 1000);
  return null;
}

async function fetchChannelPrograms(channelId) {
  const programs = [];
  for (let day = 0; day < 3; day++) {
    const url = `${BASE_URL}/tvguide/channeldetail/${channelId}/${day}`;
    try {
      const resp = await fetch(url, { headers: FETCH_HEADERS });
      if (!resp.ok) continue;
      const html = await resp.text();

      // 方式1：__NEXT_DATA__ JSON
      const ndMatch = html.match(/__NEXT_DATA__\s*=\s*(\{[\s\S]*?\})\s*<\/script>/);
      if (ndMatch) {
        try {
          const data = JSON.parse(ndMatch[1]);
          const list = data?.props?.pageProps?.programList ?? [];
          for (const p of list) {
            const dt = parseTime(String(p.startTime ?? ""));
            if (dt) {
              programs.push({
                ch: channelId,
                title: String(p.programName ?? "").trim(),
                start: String(p.startTime ?? ""),
                live: !!(p.isLive || p.liveTag),
                dt,
              });
            }
          }
          if (programs.length) continue;
        } catch {}
      }

      // 方式2：inline JSON 碎片
      const re = /\{"programName"\s*:\s*"([^"]+)"[^}]*?"startTime"\s*:\s*"([^"]+)"[^}]*?\}/g;
      for (const m of html.matchAll(re)) {
        const dt = parseTime(m[2]);
        if (dt) {
          programs.push({ ch: channelId, title: m[1].trim(), start: m[2], live: false, dt });
        }
      }
    } catch (e) {
      console.warn(`CH ${channelId} day=${day}: ${e}`);
    }
  }
  return programs;
}

function matchKeywords(title) {
  if (!KEYWORDS.length) return true;
  const tl = title.toLowerCase();
  return KEYWORDS.some((kw) => tl.includes(kw.toLowerCase()));
}

function buildMessage(p) {
  const icon = p.live ? "🔴" : "📺";
  const kind = p.live ? "直播即将开始 🔥" : "即将播出";
  const hkt = new Date(p.dt.getTime() + 8 * 3600_000);
  const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  const mm = String(hkt.getUTCMonth() + 1).padStart(2, "0");
  const dd = String(hkt.getUTCDate()).padStart(2, "0");
  const dow = days[hkt.getUTCDay()];
  const hh = String(hkt.getUTCHours()).padStart(2, "0");
  const mi = String(hkt.getUTCMinutes()).padStart(2, "0");
  const tStr = `${mm}/${dd}（${dow}）${hh}:${mi} HKT`;
  const chLabel = CHANNEL_NAMES[p.ch] ?? `CH ${p.ch}`;
  return (
    `${icon} <b>Now TV Sports · 开播前 ${REMIND_MINUTES} 分钟提醒</b>\n\n` +
    `🎯 <b>${p.title}</b>\n` +
    `📡 频道：CH ${p.ch} ${chLabel}\n` +
    `🕐 时间：${tStr}\n` +
    `⚡ 状态：${kind}`
  );
}

async function sendTelegram(env, text) {
  try {
    const r = await fetch(`https://api.telegram.org/bot${env.BOT_TOKEN}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: env.CHAT_ID, text, parse_mode: "HTML" }),
    });
    if (!r.ok) console.error(`TG失败 ${r.status}: ${await r.text()}`);
    return r.ok;
  } catch (e) {
    console.error(`TG网络错误: ${e}`);
    return false;
  }
}

export default {
  async fetch(request, env, ctx) {
    return new Response("OK", { status: 200 });
  },
  async scheduled(event, env, ctx) {
    const allPrograms = [];
    for (const chId of CHANNEL_IDS) {
      const progs = await fetchChannelPrograms(chId);
      allPrograms.push(...progs);
      console.log(`CH ${chId} → ${progs.length} 个节目`);
    }

    const nowMs = Date.now();
    const hiMs = REMIND_MINUTES * 60_000;
    const loMs = (REMIND_MINUTES - 1) * 60_000;

    for (const p of allPrograms) {
      if (!matchKeywords(p.title)) continue;
      const diff = p.dt.getTime() - nowMs;
      if (diff <= loMs || diff > hiMs) continue;

      const key = `${p.ch}|${p.start}|${p.title}`;
      const alreadySent = await env.SENT_KV.get(key);
      if (alreadySent) continue;

      const ok = await sendTelegram(env, buildMessage(p));
      if (ok) {
        await env.SENT_KV.put(key, "1", { expirationTtl: 86400 });
        console.log(`✅ 已提醒：${p.title} (CH ${p.ch})`);
      }
    }
  },
};

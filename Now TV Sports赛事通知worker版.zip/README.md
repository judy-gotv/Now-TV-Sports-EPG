# Now TV Sports EPG — Telegram 开播提醒

自动抓取 Now TV Sports 节目表，在节目开播前 5 分钟通过 Telegram 推送提醒。运行在 Cloudflare Workers 上，完全免费，无需服务器。

## 功能

- 每 3 分钟自动抓取一次节目表（今天 + 明天 + 后天）
- 监控 8 个 Now TV 体育频道
- 开播前 5 分钟推送 Telegram 通知
- 支持关键词过滤（只提醒指定节目）
- 用 KV 存储已发送记录，不会重复推送

## 监控频道

| 频道 ID | 名称 | 主要内容 |
|--------|------|---------|
| 611 | Now Sports 4K 1 | 英超 4K |
| 612 | Now Sports 4K 2 | F1 赛车 4K |
| 621 | Premier League 1 | 英超 |
| 622 | Premier League 2 | 英超 |
| 623 | Premier League 3 | 英超 |
| 630 | Now Sports Prime | 综合体育 |
| 631 | Now Sports Prime 2 | 综合体育 |
| 632 | Now Sports 2 | 西甲 |
| 633 | Now Sports 3 | 西甲 / FA Cup |
| 634 | Now Sports 4 | WTA 网球 |
| 635 | Now Sports 5 | 综合体育 |
| 636 | Now Sports 6 | ATP 网球 |
| 640 | MUTV | 曼联专属 |
| 641 | NBA | NBA 篮球 |
| 680 | Now Sports Plus | 综合体育 |

## 部署到 Cloudflare Workers

### 第一步：创建 KV 命名空间

1. 登录 [dash.cloudflare.com](https://dash.cloudflare.com)
2. 左侧菜单 → **Workers & Pages** → **KV**
3. 点 **+ Create Instance**，名称填 `NOWTV_SENT`

### 第二步：创建 Worker

1. **Workers & Pages** → **Create** → **Create Worker**
2. 名称填 `nowtv-sports-epg`，点 **Deploy**
3. 部署后点 **Edit code**，删掉默认代码
4. 将 `worker.js` 全部内容粘贴进去，点 **Deploy**

### 第三步：绑定 KV 与填入密钥

进入 Worker → **绑定** 选项卡 → **添加绑定**：

| 类型 | 变量名 | 值 |
|------|--------|-----|
| KV 命名空间 | `SENT_KV` | `NOWTV_SENT` |
| 机密 | `BOT_TOKEN` | 你的 Telegram Bot Token |
| 机密 | `CHAT_ID` | 你的 Telegram Chat ID（群组为负数） |

### 第四步：设置定时触发

进入 Worker → **设置** → **触发事件** → **添加 Cron 触发器**：

```
*/3 * * * *
```

## 获取 Telegram 信息

**Bot Token**：向 [@BotFather](https://t.me/BotFather) 发送 `/newbot` 创建机器人

**个人 Chat ID**：向 [@userinfobot](https://t.me/userinfobot) 发送任意消息即可获取

**群组 Chat ID**：将 Bot 加入群组后，访问以下链接，找 `"chat":{"id":` 后面的负数：
```
https://api.telegram.org/bot你的BOT_TOKEN/getUpdates
```

## 自定义配置

编辑 `worker.js` 顶部的配置区：

```js
// 提前几分钟提醒
const REMIND_MINUTES = 5;

// 关键词过滤（留空 = 全部节目；填关键词只提醒匹配的节目）
const KEYWORDS = [];
// 示例：const KEYWORDS = ["Premier League", "直播", "NBA"];

// 监控的频道 ID
const CHANNEL_IDS = ["611", "621", "622", "623", "630", "631", "635", "680"];
```

## 通知格式示例

```
🔴 Now TV Sports · 开播前 5 分钟提醒

🎯 Premier League 25/26 - Man City vs Arsenal
📡 频道：CH 621 Premier League 1
🕐 时间：05/02（Fri）23:00 HKT
⚡ 状态：直播即将开始 🔥
```

## 文件说明

| 文件 | 说明 |
|------|------|
| `worker.js` | Cloudflare Workers 部署文件（直接粘贴到控制台） |
| `nowtv_reminder_auto.py` | 原 Python 版本（本地运行备用） |
